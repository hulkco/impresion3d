                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1833143
Fidget Spinner Warped by Nath5 is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

My take on the fidget spinner craze.  I printed mine with 20% inflil.  The holes for the bearings are purposely tight. I used a hammer and slowly tapped them in. Once in they should move at all.  The outside caps are optional, the center cap is also tight again use a hammer to gently tap it into place.

Here is a link to the bearings I used, they are from Amazon and work quite well for the price:
https://www.amazon.com/gp/product/B0150BF0XU/ref=oh_aui_detailpage_o02_s00?ie=UTF8&psc=1

Let me know if anything doesn't fit well on your printer and I will try to get a version that will work for you!

# Print Settings

Printer: Prusa I3 MK2
Rafts: No
Supports: No
Resolution: .2
Infill: 20%